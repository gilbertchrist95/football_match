package com.treblig.footballmatch.ui.match_event

enum class Match {
    PREV,
    NEXT
}