package com.treblig.footballmatch.pojo


data class MatchEventResponse(val events: List<Event>?)






