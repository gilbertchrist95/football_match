package com.treblig.footballmatch.pojo

data class Team(val idTeam: String?, val strTeamBadge: String?)