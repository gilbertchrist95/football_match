package com.treblig.footballmatch.pojo

data class LeagueResponse(val leagues: List<League>)