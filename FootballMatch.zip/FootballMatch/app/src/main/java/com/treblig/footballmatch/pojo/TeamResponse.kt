package com.treblig.footballmatch.pojo

data class TeamResponse(val teams: List<Team>?)